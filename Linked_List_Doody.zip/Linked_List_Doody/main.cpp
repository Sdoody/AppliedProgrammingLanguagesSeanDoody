//
//  main.cpp
//  Linked_List_Doody
//
//  Created by Sean Doody on 9/27/17.
//  Copyright © 2017 Sean Doody. All rights reserved.
//

#include <iostream>
#include "Linked_Lists.hpp"


int main(int argc, const char * argv[]) {
    
    Headnode List;
    
    List.AddNode(1);
    List.AddNode(2);
    List.AddNode(3);
    List.AddNode(4);
    List.AddNode(5);
    List.AddNode(6);
    List.AddNode(7);
    List.AddNode(8);
    List.AddNode(9);
    List.AddNode(10);
    List.PrintNode();
    
    List.DeleteNode(3);
    List.DeleteNode(10);
    List.DeleteNode(1);
    List.DeleteNode(75);
    List.PrintNode();
        
    return 0;
}
