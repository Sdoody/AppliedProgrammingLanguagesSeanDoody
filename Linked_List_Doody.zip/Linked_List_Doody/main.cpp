//
//  main.cpp
//  Linked_List_Doody

#include <iostream>
#include "Linked_Lists.hpp"
using namespace std;


int main(int argc, const char * argv[]) {
   int c;
    Headnode List;
    
    cout << "Please enter 10 elements for the List " << endl;
    // adding elements to the list
    
    for(int i = 1; i <= 10; i++){
        cin >> c;
        List.AddNode(c);
        
    }
        // input for deleteting the elements of the list
    
    for(int x = 0; x <= 10; x++){
        cout << "Please enter values to remove " << endl;
        cin >> c;
        List.DeleteNode(c);
        cout << endl;
       // List.PrintNode();
        
    }
    
   /*
    List.AddNode(1);
    List.AddNode(2);
    List.AddNode(3);
    List.AddNode(4);
    List.AddNode(5);
    List.AddNode(6);
    List.AddNode(7);
    List.AddNode(8);
    List.AddNode(9);
    List.AddNode(10);
    List.PrintNode();
    
    List.DeleteNode(3);
    List.DeleteNode(10);
    List.DeleteNode(1);
    List.DeleteNode(75);
    */
    cout << endl;
    
     List.PrintNode();
    
    return 0;
}
