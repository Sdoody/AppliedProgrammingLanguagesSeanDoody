//
//  Linked_Lists.cpp
//  Linked_List_Doody
//
//  Created by Sean Doody on 9/27/17.
//  Copyright © 2017 Sean Doody. All rights reserved.
//

#include "Linked_Lists.hpp"
#include <iostream>
using namespace std;

Headnode::Headnode(){
    head = NULL;
    current = NULL;
    temp = NULL;
        
}

void Headnode::AddNode(int addElement){
    nodePtr n = new node;
    n->next = NULL;
    n->element = addElement;
    
    if(head != NULL ){
        current = head;
        while(current->next != NULL){
            current = current->next;
        }
        current ->next = n;
    }
    else {
        head = n;
    }
}

void Headnode::DeleteNode(int DelElement){
    nodePtr delPtr = NULL;
    temp = head;
    current = head;
    while(current != NULL && current->element != DelElement){
        temp = current;
        current = current->next;
        
    }
    if(current == NULL){
        cout << DelElement << " was not in the list" << endl;
        delete delPtr;
    }
    else{
        //patches the hole that is in the list
        delPtr = current;
        current =  current->next;
        temp->next = current;
        if(delPtr == head){
            head = head -> next;
            temp = NULL;
        }
        delete delPtr;
        
        cout << "The element " << DelElement << " was deleted" << endl;
    }
}

void Headnode::PrintNode(){
    
    current = head;
    while(current != NULL){
       cout << current->element << endl;
        current = current->next;
    }
    
}

