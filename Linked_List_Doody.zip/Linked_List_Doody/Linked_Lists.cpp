//
//  Linked_Lists.cpp
//  Linked_List_Doody
//
//  Created by Sean Doody on 9/27/17.
//  Copyright © 2017 Sean Doody. All rights reserved.
//

#include "Linked_Lists.hpp"
#include <iostream>
using namespace std;

Headnode::Headnode(){
    head = NULL;
    current = NULL;
    temp = NULL;
        
} // ends HeadNode

void Headnode::AddNode(int addElement){
    // adds an element to the linked list
    
    nodePtr n = new node;
    n->next = NULL;
    n->element = addElement;
    
    if(head != NULL ){
        current = head;
        while(current->next != NULL){
            current = current->next;
            
        } // end while
        
        current ->next = n;
        
    } // end if
    
    else {
        head = n;
    }// end else
    
}// end add node

void Headnode::DeleteNode(int DelElement){
    // deletes and element from the linked list
    
    nodePtr delPtr = NULL;
    temp = head;
    current = head;
    while(current != NULL && current->element != DelElement){
        temp = current;
        current = current->next;
        
    }// end while
    
    if(current == NULL){
        cout << DelElement << " was not in the list" << endl;
        delete delPtr;
    }// end if
    
    else{
        //patches the hole that is in the list
        delPtr = current;
        current =  current->next;
        temp->next = current;
        if(delPtr == head){
            head = head -> next;
            temp = NULL;
            
        }
        
        // deletes the pointer to free the memory
        delete delPtr;
        
        cout << "The element " << DelElement << " was deleted" << endl;
    }// end else
} // end deleteNode

void Headnode::PrintNode(){
    // prints the current elements in the list
    
    
    current = head;
    while(current != NULL){
       cout << current->element << endl;
        current = current->next;
    } // end while
    
} //end print node

