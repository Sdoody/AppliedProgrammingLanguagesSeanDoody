//
//  Linked_Lists.hpp
//  Linked_List_Doody
//
//  Created by Sean Doody on 9/27/17.
//  Copyright © 2017 Sean Doody. All rights reserved.
//

#ifndef Linked_Lists_hpp
#define Linked_Lists_hpp

#include <stdio.h>

using namespace std;

class Headnode{
private:
    
    typedef struct node{
        int element;
        node* next;
    }* nodePtr;
    
    nodePtr head;
    nodePtr current;
    nodePtr temp;
    
public:  // this is where the funcitons go to access the private data
        // This is the Ctor for the Headnode Class 
    Headnode();
    void AddNode(int addElement);
    void DeleteNode(int DelElement);
    void PrintNode();
    
};

#endif /* Linked_Lists_hpp */
