//
//  Stacks.h
//  Stacks_Sean
//
//  Created by Sean Doody on 10/4/17.
//  Copyright © 2017 Sean Doody. All rights reserved.
//

#ifndef Stacks_h
#define Stacks_h
using namespace std;


class Stack{
private:
    // what an item looks like
    struct item{
        int value;
        item* prev;
    };
    // what an item ptr looks like
    item* stackPtr;
public:
    void Push(int value);
    void Pop(); // takes an item off the stack
    void ReadItem(item* r); // we pass in the ptr r and look what at what r is pointing to and will display it
    void Print();
    
    Stack(); // ctor 
    ~Stack(); // dctor
    
    
};


#endif /* Stacks_h */
