//
//  Stacks_SeanDoody.cpp
//  Stacks_Sean
//
//  Created by Sean Doody on 10/4/17.
//  Copyright © 2017 Sean Doody. All rights reserved.
//

//#include "Stacks_SeanDoody.hpp"
#include <iostream>
#include "Stacks.h"

using namespace std;

Stack::Stack(){
    stackPtr = NULL; // make sure the pointer isnt pointing to anything
    
    
}

Stack::~Stack(){
    item* p1;
    item* p2;
    
    p1 = stackPtr;
    while(p1 != NULL){
        p2 = p1;
        p1 = p1->prev;
        p2->prev = NULL;
        delete p2;
        
    }
}

void Stack::Push(int value){
    item* n = new item; // creating a new item/ creating a ptr n whhich is pointing to the new item
    
    n->value = value; // places the value inisde the item
    
    if(stackPtr == NULL){
        stackPtr = n;
        stackPtr->prev = NULL; // prev pointer is == NULL
    }
    else{
        n->prev = stackPtr; // pointing to the top of the stack
        stackPtr = n; //pointing to the new top of the stack
        
    }
    
}

void Stack::ReadItem(Stack::item *r){
    cout << "-----------------\n";
    cout << "Value: " << r->value << endl;
    cout << "-----------------\n";
}

void Stack::Pop(){
    if(stackPtr == NULL){ // CHECK AND SEE IF THE STACKPOINTER IS POINTING TO ANYTHING
        cout << "There is nothing ion the stack" << endl;
    }
    else{
        item* p = stackPtr; // point to the top of the stack
        ReadItem(p); // read the contents of the stack
        stackPtr = stackPtr->prev; // making the stack pointer back up one
        p->prev = NULL;  // seperates top item from the stack
        delete p;  // deletes what used to be at the top of the stack
    }
}
void Stack::Print(){
    item* p = stackPtr; // if item* is pointing to NULL THEN nothing will happen
    
    while(p != NULL ){
        
        ReadItem(p); // read the contents of what p is pointing too
        p = p->prev; // print all items top to bottem
    }
}






