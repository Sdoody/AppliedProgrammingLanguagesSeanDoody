//
//  main.cpp
//  Stacks_Sean
//
//  Created by Sean Doody on 10/4/17.
//  Copyright © 2017 Sean Doody. All rights reserved.
//

#include <iostream>
#include "Stacks.h"
using namespace std;

int main(){
    int c;

    
    Stack Items;
    
    cout << "Please enter 10 Values " << endl;
    for(int x = 1 ; x <= 5; x++){
        cin >> c;
        Items.Push(c);
    }
    cout << "Choose 3 Items to be Popped: " << endl;
    
    for(int y = 1 ; y <= 3; y++){
        cin >> c;
        Items.Pop();
    }
    
    cout << "The remaining items in the list are: " << endl;
    
        Items.Print();
    
    cout << "The items that were popped: " << endl;
    
  
    
        
    
    
    
         
    return 0;
}
